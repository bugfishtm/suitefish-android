<?php
/**
 * Suitefish Android — test catalog server (single self-contained file).
 *
 * Deploy this file at:   https://YOURHOST[:PORT]/_api/_android/fetch.php
 * The app will call:     https://YOURHOST[:PORT]/_api/_android/fetch.php
 *
 * IMPORTANT
 *   - The Suitefish app REQUIRES HTTPS. Serve this over a TLS certificate. A trusted
 *     (CA-signed) certificate works out of the box; a self-signed certificate only
 *     works if the user enables "Allow untrusted certificates" in the app.
 *   - The app treats app_image_url and app_download_url as opaque URLs: it downloads
 *     exactly what those fields contain. They can point anywhere (a CDN, object
 *     storage, another host) — they do NOT have to point back at this script.
 *   - For convenience this test file can also SERVE those two things itself, so you
 *     need no other files: it generates each app icon (?icon=...) and a placeholder
 *     APK (?apk=...). The app never knows or cares how those URLs are produced.
 *   - app_image_url points at a square PNG app icon. The generated APKs are NOT real
 *     installable apps — they only exercise the download flow. Point app_download_url
 *     at real APKs for a full install/update test.
 *
 * Endpoints handled by this file:
 *   ?lang=<code>           -> JSON catalog, titles/descriptions in that language
 *                             (de, en, es, fr, in, it, ja, kr, pt, ru, tr, zh; default en)
 *   ?icon=<App Name>       -> a square PNG app icon (color derived from the name)
 *   ?apk=<pkg>&version=x   -> a small placeholder .apk download
 */

// ---- Resolve this script's own public base URL (forced to https) -----------
function base_url(): string {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';           // includes :port if present
    $dir  = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/_api/_android/fetch.php'), '/');
    return 'https://' . $host . $dir . '/fetch.php';
}

// ---- Sub-endpoint: square PNG icon generator -------------------------------
// The icon's label and background colour are derived from the app name that is
// passed in ?icon=..., so the catalog only ever needs a plain image URL.
if (isset($_GET['icon'])) {
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=86400');

    $name = (string) $_GET['icon'];
    // Up-to-two-letter label from the first letters of the first two words.
    $words = preg_split('/\s+/', trim(preg_replace('/[^A-Za-z0-9 ]/', ' ', $name)));
    $label = '';
    foreach ($words as $w) {
        if ($w !== '') { $label .= strtoupper($w[0]); }
        if (strlen($label) >= 2) { break; }
    }
    if ($label === '') { $label = 'AP'; }

    // Deterministic colour from the name hash, brightened so it reads on dark UI.
    $h = md5($name);
    $r = 80 + (hexdec(substr($h, 0, 2)) % 176);
    $g = 80 + (hexdec(substr($h, 2, 2)) % 176);
    $b = 80 + (hexdec(substr($h, 4, 2)) % 176);

    if (function_exists('imagecreatetruecolor')) {
        $size = 192;
        $img = imagecreatetruecolor($size, $size);
        $bg   = imagecolorallocate($img, $r, $g, $b);
        $dark = imagecolorallocate($img, 18, 18, 18);
        $white = imagecolorallocate($img, 255, 255, 255);
        imagefilledrectangle($img, 0, 0, $size, $size, $dark);
        imagefilledrectangle($img, 16, 16, $size - 16, $size - 16, $bg);
        // Centered label using the built-in large font.
        $fw = imagefontwidth(5) * strlen($label);
        $fh = imagefontheight(5);
        imagestring($img, 5, (int)(($size - $fw) / 2), (int)(($size - $fh) / 2), $label, $white);
        imagepng($img);
        imagedestroy($img);
    } else {
        // GD not available: emit a 1x1 transparent PNG so the app still gets a file.
        echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=');
    }
    exit;
}

// ---- Sub-endpoint: placeholder APK download --------------------------------
if (isset($_GET['apk'])) {
    $pkg = preg_replace('/[^A-Za-z0-9._-]/', '_', $_GET['apk']);
    $ver = preg_replace('/[^A-Za-z0-9._-]/', '_', $_GET['version'] ?? '0');
    $name = $pkg . '_' . $ver . '.apk';
    $body = "Suitefish test placeholder APK\nPackage: $pkg\nVersion: $ver\n" .
            "This is NOT a real installable app; it only exercises the download flow.\n";
    header('Content-Type: application/vnd.android.package-archive');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . strlen($body));
    echo $body;
    exit;
}

// ---- Default: return the JSON catalog --------------------------------------
$self = base_url();

/**
 * Build one catalog row. app_image_url / app_download_url point back at this same
 * script only for convenience — in a real catalog they would be normal URLs to a
 * hosted PNG icon and a hosted .apk.
 */
function app(string $self, string $pkg, string $name, string $cat, string $ver,
            string $desc): array {
    return [
        'app_package'      => $pkg,
        'app_name'         => $name,
        'app_category'     => $cat,
        'app_version'      => $ver,
        'app_description'  => $desc,
        'app_image_url'    => $self . '?icon=' . rawurlencode($name),
        'app_download_url' => $self . '?apk=' . rawurlencode($pkg) . '&version=' . rawurlencode($ver),
    ];
}

$catalog = [
    app($self, 'com.suitefish.notes', 'Fish Notes', 'Productivity', '1.2.0',
        'A clean, offline notepad with markdown support and quick search. Lightweight and private.'),

    // Same package listed twice with different versions — the app must keep only the
    // newest (2.1.3) and hide 2.0.0.
    app($self, 'com.suitefish.player', 'Reef Player', 'Media', '2.0.0',
        'Older build of the Reef media player.'),
    app($self, 'com.suitefish.player', 'Reef Player', 'Media', '2.1.3',
        'A fast audio and video player with gapless playback, playlists and a compact library.'),

    app($self, 'com.suitefish.weather', 'Tide Weather', 'Weather', '3.4.1',
        'Hyper-local forecasts, radar and severe-weather alerts. No account required.'),

    app($self, 'com.suitefish.launcher', 'Coral Launcher', 'Personalization', '0.9.7',
        'A minimalist home screen launcher with gestures, hidden apps and custom icon packs.'),

    app($self, 'com.suitefish.files', 'Deep Files', 'Tools', '1.0.4',
        'A dual-pane file manager with root support, archive handling and network shares.'),

    app($self, 'com.suitefish.game.bubbles', 'Bubble Blaster', 'Games', '5.11.0',
        'A relaxing arcade shooter. Pop matching bubbles across hundreds of handcrafted levels.'),

    app($self, 'com.suitefish.wallet', 'Kelp Wallet', 'Finance', '2.2.2',
        'Track spending, budgets and recurring bills. All data stays on your device.'),
];

/*
 * Language simulation.
 *
 * The app sends the device language as ?lang=CODE (de, en, es, fr, in, it, ja, kr,
 * pt, ru, tr, zh). A real backend would return fully translated titles and
 * descriptions per language. To keep this test file small, we simulate that by:
 *   - tagging each title with the served language endonym (so you can SEE which
 *     language was requested), and
 *   - replacing the description with a short sentence written in that language.
 * Unknown languages fall back to English.
 */
$requested = isset($_GET['lang']) ? strtolower($_GET['lang']) : 'en';

// endonym label + a description template: %1$s = app name, %2$s = category.
$LANGS = [
    'en' => ['English',  '%1$s — a %2$s app. (Served in English.)'],
    'de' => ['Deutsch',  '%1$s — eine %2$s-App. (Auf Deutsch bereitgestellt.)'],
    'es' => ['Español',  '%1$s — una app de %2$s. (Servido en español.)'],
    'fr' => ['Français', '%1$s — une app de %2$s. (Fourni en français.)'],
    'in' => ['हिन्दी',    '%1$s — एक %2$s ऐप। (हिन्दी में प्रदान किया गया।)'],
    'it' => ['Italiano', '%1$s — un\'app di %2$s. (Fornito in italiano.)'],
    'ja' => ['日本語',    '%1$s — %2$s アプリ。（日本語で提供。）'],
    'kr' => ['한국어',    '%1$s — %2$s 앱. (한국어로 제공됩니다.)'],
    'pt' => ['Português', '%1$s — um app de %2$s. (Fornecido em português.)'],
    'ru' => ['Русский',  '%1$s — приложение категории %2$s. (Предоставлено на русском.)'],
    'tr' => ['Türkçe',   '%1$s — bir %2$s uygulaması. (Türkçe olarak sağlanmıştır.)'],
    'zh' => ['中文',      '%1$s — %2$s 应用。（以中文提供。）'],
];

$lang = isset($LANGS[$requested]) ? $requested : 'en';
[$endonym, $descTemplate] = $LANGS[$lang];

foreach ($catalog as &$row) {
    $baseName = $row['app_name'];
    $row['app_description'] = sprintf($descTemplate, $baseName, $row['app_category']);
    // Simulation marker so the served language is visible in the title too.
    $row['app_name'] = $baseName . ' · ' . $endonym;
}
unset($row);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
echo json_encode($catalog, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
