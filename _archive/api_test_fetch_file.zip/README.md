# Suitefish — test catalog server

A single self-contained PHP file for testing the Suitefish Android app end-to-end.

## Deploy

1. Copy the `_api` folder to the web root of an **HTTPS** host so the file is reachable at:

   ```
   https://YOURHOST[:PORT]/_api/_android/fetch.php
   ```

   HTTPS is mandatory. A **CA-signed** certificate works out of the box. A
   **self-signed** certificate works only if you turn on **Allow untrusted
   certificates** in the app (onboarding for a custom server, or Settings). Plain
   HTTP is always rejected.

2. In the app's onboarding (or Settings → Change server), pick **Custom server** and
   enter your host, e.g. `yourhost.com` or `yourhost.com:8443`. The app appends
   `/_api/_android/` automatically.

## What the script does

`fetch.php` handles three things from one file:

| Request | Response |
| --- | --- |
| `fetch.php?lang=<code>` | JSON catalog with titles/descriptions in that language |
| `fetch.php?icon=<App Name>` | A square PNG app icon (colour derived from the name) |
| `fetch.php?apk=<pkg>&version=x.y.z` | A small placeholder `.apk` download |

The app automatically appends `?lang=<code>` based on the device language. Supported
codes: `de, en, es, fr, in, it, ja, kr, pt, ru, tr, zh` (default `en`). To simulate
localization, the test server tags each title with the served language and returns a
short description written in that language; a real backend would return fully
translated titles and descriptions.

The app treats `app_image_url` and `app_download_url` as opaque URLs — it downloads
exactly what those fields contain, so they can point at any host (a CDN, object
storage, etc.), not just this script. This test file serves them itself only so you
don't need to host anything else. `app_image_url` is a square app icon shown in the
store; there is no "colour" field in the API — the test server just picks a colour
from the app name.

The catalog includes one package (`com.suitefish.player`) listed twice with different
versions so you can verify the app keeps only the newest (2.1.3). The generated APKs
are **not** real installable apps — they only exercise the download flow. Point
`app_download_url` at real APKs for a full install/update test.

## JSON shape

```json
[
  {
    "app_package": "com.unique.identifier",
    "app_name": "App name",
    "app_category": "Category",
    "app_version": "1.2.3",
    "app_description": "Description text",
    "app_image_url": "https://.../image.png",
    "app_download_url": "https://.../pkg_1.2.3.apk"
  }
]
```
